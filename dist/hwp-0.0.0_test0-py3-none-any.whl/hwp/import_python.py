def test3():
	print("test3 fawefaweff")