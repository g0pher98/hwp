def test1():
	print("jojo")