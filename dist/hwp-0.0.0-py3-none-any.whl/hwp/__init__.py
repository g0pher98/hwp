def print_hello():
	print("hello~")
	return

def open_hwp():
	print("hwp is opened")
	return True
