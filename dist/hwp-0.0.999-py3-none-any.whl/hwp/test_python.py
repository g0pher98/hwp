def test2():
	print("hihie")